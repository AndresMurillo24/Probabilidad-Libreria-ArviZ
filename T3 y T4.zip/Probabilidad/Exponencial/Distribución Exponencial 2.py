"""
Ejercicio 2 — Distribución Exponencial
Falla de máquina en una fábrica
-----------------------------------------------------------
- Tasa λ = 1/12 h
- Calcula:
  P(X ≤ 8) y P(X ≥ 15)
- Gráfica de la distribución y áreas sombreadas.
"""

import numpy as np
import matplotlib.pyplot as plt
import arviz as az
from scipy.stats import expon

# -----------------------------
# Parámetros
# -----------------------------
media = 12  # horas
lmbda = 1 / media
x = np.linspace(0, 40, 300)

# -----------------------------
# Cálculos de probabilidades
# -----------------------------
p_x_le_8 = expon.cdf(8, scale=1/lmbda)       # P(X ≤ 8)
p_x_ge_15 = 1 - expon.cdf(15, scale=1/lmbda) # P(X ≥ 15)

print("=== Ejercicio 2 — Máquina en fábrica ===")
print(f"λ = {lmbda:.4f}")
print(f"P(X ≤ 8) = {p_x_le_8:.4f}")
print(f"P(X ≥ 15) = {p_x_ge_15:.4f}")
print("========================================")

# -----------------------------
# Gráfica
# -----------------------------
y = expon.pdf(x, scale=1/lmbda)

plt.figure(figsize=(10, 6))
plt.plot(x, y, label='Densidad Exponencial', color='purple')

# sombrear área P(X ≤ 8)
x_le_8 = np.linspace(0, 8, 100)
plt.fill_between(x_le_8, expon.pdf(x_le_8, scale=1/lmbda), alpha=0.4, color='orange', label='P(X ≤ 8)')

# sombrear área P(X ≥ 15)
x_ge_15 = np.linspace(15, 40, 100)
plt.fill_between(x_ge_15, expon.pdf(x_ge_15, scale=1/lmbda), alpha=0.4, color='green', label='P(X ≥ 15)')

plt.title('Distribución Exponencial — Máquina en fábrica')
plt.xlabel('Tiempo (horas)')
plt.ylabel('f(x)')
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
plt.show()

# ArviZ nos ayuda a visualizar y explorar la forma de la distribución de datos simulados.
az.plot_dist(np.random.exponential(1/lmbda, size=1000), kind="hist", bins=30)
plt.title("Visualización con ArviZ — Distribución Exponencial (Fábrica)")
plt.xlabel("Tiempo (horas)")
plt.ylabel("Densidad")
plt.tight_layout()
plt.show()
