"""
Ejercicio 1 — Distribución Exponencial
Centro de llamadas: tiempos entre llegadas
-----------------------------------------------------------
- Tasa λ = 0.2 (1/5 min)
- Calcula:
  P(X ≤ 3) y P(X > 7)
- Gráfica de la distribución y área sombreada.
"""

import numpy as np
import matplotlib.pyplot as plt
import arviz as az
from scipy.stats import expon

# -----------------------------
# Parámetros
# -----------------------------
media = 5  # minutos
lmbda = 1 / media  # tasa λ
x = np.linspace(0, 20, 200)

# -----------------------------
# Cálculos de probabilidades
# -----------------------------
p_x_le_3 = expon.cdf(3, scale=1/lmbda)       # P(X ≤ 3)
p_x_gt_7 = 1 - expon.cdf(7, scale=1/lmbda)   # P(X > 7)

print("=== Ejercicio 1 — Centro de llamadas ===")
print(f"λ = {lmbda:.2f}")
print(f"P(X ≤ 3) = {p_x_le_3:.4f}")
print(f"P(X > 7) = {p_x_gt_7:.4f}")
print("=======================================")

# -----------------------------
# Gráfica
# -----------------------------
y = expon.pdf(x, scale=1/lmbda)

plt.figure(figsize=(10, 6))
plt.plot(x, y, label='Densidad Exponencial', color='navy')

# sombrear área para P(X ≤ 3)
x_le_3 = np.linspace(0, 3, 100)
plt.fill_between(x_le_3, expon.pdf(x_le_3, scale=1/lmbda), alpha=0.4, color='orange', label='P(X ≤ 3)')

# sombrear área para P(X > 7)
x_gt_7 = np.linspace(7, 20, 100)
plt.fill_between(x_gt_7, expon.pdf(x_gt_7, scale=1/lmbda), alpha=0.4, color='green', label='P(X > 7)')

plt.title('Distribución Exponencial — Centro de llamadas')
plt.xlabel('Tiempo (minutos)')
plt.ylabel('f(x)')
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
plt.show()


# Aquí podríamos usar az.plot_dist para mostrar la forma general de la distribución.
az.plot_dist(np.random.exponential(1/lmbda, size=1000), kind="hist", bins=30)
plt.title("Visualización con ArviZ — Distribución Exponencial")
plt.xlabel("Tiempo (minutos)")
plt.ylabel("Densidad")
plt.tight_layout()
plt.show()
