# ===============================================
# Ejercicio 1: Peso de paquetes en una empresa
# Distribución Normal — Documentado paso a paso
# ===============================================

# Importamos las librerías necesarias
import numpy as np                    # Para cálculos numéricos
import arviz as az                    # Para visualización estadística (ArviZ)
import matplotlib.pyplot as plt       # Para crear gráficos
from scipy.stats import norm          # Para funciones de distribución normal

# -----------------------------
# PARÁMETROS DE LA DISTRIBUCIÓN
# -----------------------------
mu = 5         # Media (kg)
sigma = 1.2    # Desviación estándar (kg)

# Intervalos que queremos analizar
x1, x2 = 4.5, 6   # Para el primer cálculo: P(4.5 < X < 6)
x3 = 6.5          # Para el segundo cálculo: P(X > 6.5)

# -----------------------------
# CÁLCULO DE PROBABILIDADES
# -----------------------------
# norm.cdf(x, mu, sigma) calcula la función de distribución acumulada F(x)
p_intervalo = norm.cdf(x2, mu, sigma) - norm.cdf(x1, mu, sigma)
p_mayor = 1 - norm.cdf(x3, mu, sigma)

# Mostramos los resultados en consola
print(f"P(4.5 < X < 6) = {p_intervalo:.4f}")
print(f"P(X > 6.5) = {p_mayor:.4f}")

# -----------------------------
# CREACIÓN DE GRÁFICA
# -----------------------------
# Definimos un rango de valores para graficar la curva
x = np.linspace(mu - 4*sigma, mu + 4*sigma, 1000)
y = norm.pdf(x, mu, sigma)  # Función de densidad de probabilidad

# 📌 Uso de ArviZ:
# az.plot_dist() permite visualizar la distribución de manera simple y elegante.
# Aquí no usamos datos muestrales reales, pero graficamos la distribución sobre el rango definido.
az.plot_dist(x, kind="hist", hist_kwargs={"density": True})

# Graficamos la curva de densidad normal
plt.plot(x, y, color='blue')

# -----------------------------
# SOMBREADO DE ÁREAS DE INTERÉS
# -----------------------------
# Área para P(4.5 < X < 6)
x_fill = np.linspace(x1, x2, 200)
plt.fill_between(x_fill, norm.pdf(x_fill, mu, sigma),
                 color='orange', alpha=0.5, label='4.5 < X < 6')

# Área para P(X > 6.5)
x_fill2 = np.linspace(x3, mu + 4*sigma, 200)
plt.fill_between(x_fill2, norm.pdf(x_fill2, mu, sigma),
                 color='green', alpha=0.5, label='X > 6.5')

# Títulos y etiquetas
plt.title('Distribución Normal — Peso de Paquetes')
plt.xlabel('Peso (kg)')
plt.ylabel('Densidad de probabilidad')
plt.legend()

# Mostramos el gráfico
plt.show()
