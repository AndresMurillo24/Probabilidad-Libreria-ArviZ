# ===============================================
# Ejercicio 2: Tiempo de ensamblaje en una fábrica
# Distribución Normal — Documentado paso a paso
# ===============================================

# Importamos librerías necesarias
import numpy as np
import arviz as az                    # 📌 Usaremos ArviZ para visualizar la distribución
import matplotlib.pyplot as plt
from scipy.stats import norm

# -----------------------------
# PARÁMETROS DE LA DISTRIBUCIÓN
# -----------------------------
mu = 20       # Media (minutos)
sigma = 3     # Desviación estándar (minutos)

# Intervalos que queremos analizar
x1, x2 = 18, 24   # Para P(18 < X < 24)
x3 = 25          # Para P(X > 25)

# -----------------------------
# CÁLCULO DE PROBABILIDADES
# -----------------------------
p_intervalo = norm.cdf(x2, mu, sigma) - norm.cdf(x1, mu, sigma)
p_mayor = 1 - norm.cdf(x3, mu, sigma)

print(f"P(18 < X < 24) = {p_intervalo:.4f}")
print(f"P(X > 25) = {p_mayor:.4f}")

# -----------------------------
# CREACIÓN DE GRÁFICA
# -----------------------------
x = np.linspace(mu - 4*sigma, mu + 4*sigma, 1000)
y = norm.pdf(x, mu, sigma)

# 📌 Uso de ArviZ nuevamente:
# Nos permite mostrar visualmente la forma de la distribución normal.
az.plot_dist(x, kind="hist", hist_kwargs={"density": True})

# Graficamos la curva normal
plt.plot(x, y, color='blue')

# -----------------------------
# SOMBREADO DE ÁREAS
# -----------------------------
# Para P(18 < X < 24)
x_fill = np.linspace(x1, x2, 200)
plt.fill_between(x_fill, norm.pdf(x_fill, mu, sigma),
                 color='orange', alpha=0.5, label='18 < X < 24')

# Para P(X > 25)
x_fill2 = np.linspace(x3, mu + 4*sigma, 200)
plt.fill_between(x_fill2, norm.pdf(x_fill2, mu, sigma),
                 color='green', alpha=0.5, label='X > 25')

# Títulos y etiquetas
plt.title('Distribución Normal — Tiempo de Ensamblaje')
plt.xlabel('Tiempo (minutos)')
plt.ylabel('Densidad de probabilidad')
plt.legend()

# Mostrar la figura
plt.show()
