

import numpy as np
import matplotlib.pyplot as plt
import arviz as az                 # Para visualización complementaria
from scipy.stats import poisson    # Distribución de Poisson

# -----------------------------
# PARÁMETROS
# -----------------------------
lam = 2.5               # promedio de defectuosos por día
x = np.arange(0, 12)    # rango para graficar (0 a 11 defectuosos)

# -----------------------------
# CÁLCULOS DE PROBABILIDAD
# -----------------------------
# a) P(X = 0)
x_exacto = 0
p_exacto = poisson.pmf(x_exacto, lam)

# b) P(X ≥ 3) = 1 - P(X ≤ 2)
p_menor_igual_2 = sum(poisson.pmf(k, lam) for k in range(0, 3))
p_mayor_igual_3 = 1 - p_menor_igual_2

# Imprimir en consola
print("=== Resultados (Distribución de Poisson) ===")
print(f"Parámetro λ = {lam}")
print(f"P(X = {x_exacto}) = {p_exacto:.4f}")
print(f"P(X ≥ 3) = {p_mayor_igual_3:.4f}")
print("============================================")

# -----------------------------
# PREPARAR DATOS PARA LA GRÁFICA
# -----------------------------
y = poisson.pmf(x, lam)       # Probabilidad para cada x
mask_ge_3 = x >= 3            # Para resaltar X ≥ 3

# -----------------------------
# VISUALIZACIÓN
# -----------------------------
plt.figure(figsize=(12, 6))

# ArviZ: histograma de referencia
# (opcional, se puede comentar si no está instalado)
az.plot_dist(x, kind="hist", hist_kwargs={"density": True, "alpha": 0.15})

# Barras base
plt.bar(x, y, color='steelblue', alpha=0.75, label='P(X = x) — Poisson(2.5)')

# Resaltar región X ≥ 3
plt.bar(x[mask_ge_3], y[mask_ge_3], color='lightcoral', alpha=0.9, label='Región X ≥ 3')

# Punto P(X=0)
plt.scatter([x_exacto], [p_exacto], color='orange', s=160, edgecolors='black',
            zorder=5, label=f'P(X={x_exacto}) = {p_exacto:.4f}')

# Anotación de P(X ≥ 3)
plt.annotate(f'P(X ≥ 3) = {p_mayor_igual_3:.4f}',
             xy=(4.5, max(y)*0.9), xytext=(5, max(y)*1.1),
             bbox=dict(boxstyle="round,pad=0.3", fc="lightyellow", ec="gray"),
             arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=-0.3"))

# Estética
plt.title('Distribución de Poisson — Componentes defectuosos (1 día)')
plt.xlabel('Número de componentes defectuosos')
plt.ylabel('Probabilidad P(X=x)')
plt.xticks(x)
plt.ylim(0, max(y)*1.25)
plt.grid(axis='y', linestyle='--', alpha=0.4)
plt.legend()

plt.tight_layout()
plt.show()

