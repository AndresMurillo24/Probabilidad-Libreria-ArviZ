
import numpy as np
import matplotlib.pyplot as plt
import arviz as az                 # Para visualizaciones estadísticas sencillas (explicado abajo)
from scipy.stats import poisson    # Funciones de Poisson (pmf, cdf, etc.)

# -----------------------------
# PARÁMETROS
# -----------------------------
lam = 4.5              # media (clientes por 10 minutos)
x = np.arange(0, 13)   # rango de valores a mostrar en la gráfica (0..12)

# -----------------------------
# CÁLCULOS DE PROBABILIDAD
# -----------------------------
# a) P(X = 2)
x_exacto = 2
p_exacto = poisson.pmf(x_exacto, lam)

# b) P(X ≥ 5) = 1 - P(X ≤ 4)
# calculamos P(X ≤ 4) sumando P(0) a P(4)
p_menor_igual_4 = sum(poisson.pmf(k, lam) for k in range(0, 5))
p_mayor_igual_5 = 1 - p_menor_igual_4

# Imprimimos resultados en consola (claro y formateado)
print("=== Resultados (Distribución de Poisson) ===")
print(f"Parámetro λ = {lam}")
print(f"P(X = {x_exacto}) = {p_exacto:.4f}")
print(f"P(X ≥ 5) = {p_mayor_igual_5:.4f}")
print("============================================")

# -----------------------------
# PREPARAR DATOS PARA LA GRÁFICA
# -----------------------------
y = poisson.pmf(x, lam)         # vector de probabilidades para cada x
mask_ge_5 = x >= 5              # máscara booleana para x >= 5 (zona a resaltar)

# -----------------------------
# VISUALIZACIÓN
# -----------------------------
plt.figure(figsize=(12, 6))

# -----------------------------
# Uso de ArviZ:
# az.plot_dist es útil para mostrar una "vista" rápida de una distribución.
# Aquí lo uso para crear un histograma base que ayude a visualizar la forma
# de la distribución antes de dibujar las barras (no reemplaza las barras).
#
# Nota: ArviZ está pensado para trabajo bayesiano, pero su plot_dist
# es una utilidad cómoda para ver distribuciones. No se usa para cálculos.
# -----------------------------
az.plot_dist(x, kind="hist", hist_kwargs={"density": True, "alpha": 0.15})

# --- Dibujamos las barras (más legible para una Poisson discreta) ---
# Pongo color por defecto y luego sobrepongo las barras x>=5 con otro color.
plt.bar(x, y, color='steelblue', alpha=0.75, label='P(X = x) — Poisson(4.5)')

# Resaltamos las barras para la región X >= 5
plt.bar(x[mask_ge_5], y[mask_ge_5], color='lightcoral', alpha=0.9, label='Región X ≥ 5')

# --- Marcadores para los puntos de interés ---
# Punto exacto X=2 (naranja)
plt.scatter([x_exacto], [p_exacto], color='orange', s=160, edgecolors='black',
            zorder=5, label=f'P(X={x_exacto}) = {p_exacto:.4f}')

# Sombreado / etiqueta mostrando P(X ≥ 5) en la gráfica
# (colocamos una anotación con la probabilidad calculada)
plt.annotate(f'P(X ≥ 5) = {p_mayor_igual_5:.4f}',
             xy=(6.5, max(y)*0.9), xytext=(7.0, max(y)*1.05),
             bbox=dict(boxstyle="round,pad=0.3", fc="lightyellow", ec="gray"),
             arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=-0.3"))

# --- Estética ---
plt.title('Distribución de Poisson — Llegada de clientes (10 minutos)')
plt.xlabel('Número de clientes')
plt.ylabel('Probabilidad P(X=x)')
plt.xticks(x)
plt.ylim(0, max(y)*1.25)
plt.grid(axis='y', linestyle='--', alpha=0.4)
plt.legend()

plt.tight_layout()
plt.show()


