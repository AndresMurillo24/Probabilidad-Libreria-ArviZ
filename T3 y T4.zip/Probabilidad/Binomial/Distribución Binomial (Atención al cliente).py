"""
Ejercicio 1 — Distribución Binomial (Atención al cliente)
Validación de resultados y gráfica.
"""

import numpy as np
import matplotlib.pyplot as plt
import arviz as az
from scipy.stats import binom

# -----------------------------
# Parámetros
# -----------------------------
n = 10           # número de ensayos
p = 0.30         # probabilidad de éxito
x = np.arange(0, n+1)

# -----------------------------
# Cálculos
# -----------------------------
k1 = 4
p_x4 = binom.pmf(k1, n, p)

# P(X ≥ 6)
p_x_ge_6 = 1 - binom.cdf(5, n, p)

print("=== Resultados (Binomial) ===")
print(f"P(X = {k1}) = {p_x4:.4f}")
print(f"P(X ≥ 6) = {p_x_ge_6:.4f}")
print("=============================")

# -----------------------------
# Gráfica
# -----------------------------
y = binom.pmf(x, n, p)
mask_ge_6 = x >= 6

plt.figure(figsize=(10, 6))
az.plot_dist(x, kind="hist", hist_kwargs={"density": True, "alpha": 0.15})

plt.bar(x, y, alpha=0.75, label='Distribución Binomial')
plt.bar(x[mask_ge_6], y[mask_ge_6], color='lightcoral', label='X ≥ 6')
plt.scatter([k1], [p_x4], color='orange', s=160, edgecolors='black', zorder=5,
            label=f'P(X={k1}) = {p_x4:.4f}')

plt.title('Distribución Binomial — Casos resueltos')
plt.xlabel('Número de éxitos')
plt.ylabel('Probabilidad P(X=x)')
plt.xticks(x)
plt.grid(axis='y', linestyle='--', alpha=0.4)
plt.legend()
plt.tight_layout()
plt.show()

# -----------------------------
# Nota
# -----------------------------
print("\nNotas:")
print("- La probabilidad se calcula con scipy.stats.binom.")
print("- Se usa ArviZ para una visualización suave de fondo.")
print("- Se resaltan en rojo los valores X ≥ 6.")
