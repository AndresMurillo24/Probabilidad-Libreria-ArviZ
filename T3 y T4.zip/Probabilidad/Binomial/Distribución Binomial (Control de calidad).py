"""
Ejercicio 2 — Distribución Binomial (Control de calidad)
Validación de resultados y gráfica.
"""

import numpy as np
import matplotlib.pyplot as plt
import arviz as az
from scipy.stats import binom

# -----------------------------
# Parámetros
# -----------------------------
n = 20
p = 0.15
x = np.arange(0, n+1)

# -----------------------------
# Cálculos
# -----------------------------
k2 = 3
p_x3 = binom.pmf(k2, n, p)

# P(X ≤ 2)
p_x_le_2 = binom.cdf(2, n, p)

print("=== Resultados (Binomial) ===")
print(f"P(X = {k2}) = {p_x3:.4f}")
print(f"P(X ≤ 2) = {p_x_le_2:.4f}")
print("=============================")

# -----------------------------
# Gráfica
# -----------------------------
y = binom.pmf(x, n, p)
mask_le_2 = x <= 2

plt.figure(figsize=(10, 6))
az.plot_dist(x, kind="hist", hist_kwargs={"density": True, "alpha": 0.15})

plt.bar(x, y, alpha=0.75, label='Distribución Binomial')
plt.bar(x[mask_le_2], y[mask_le_2], color='lightgreen', label='X ≤ 2')
plt.scatter([k2], [p_x3], color='orange', s=160, edgecolors='black', zorder=5,
            label=f'P(X={k2}) = {p_x3:.4f}')

plt.title('Distribución Binomial — Productos defectuosos')
plt.xlabel('Número de defectuosos')
plt.ylabel('Probabilidad P(X=x)')
plt.xticks(x)
plt.grid(axis='y', linestyle='--', alpha=0.4)
plt.legend()
plt.tight_layout()
plt.show()

# -----------------------------
# Nota
# -----------------------------
print("\nNotas:")
print("- La probabilidad se calcula con scipy.stats.binom.")
print("- Se usa ArviZ para una visualización de fondo.")
print("- Se resaltan en verde los valores X ≤ 2.")
