
import numpy as np
import matplotlib.pyplot as plt


# Valores posibles para X
x_vals = np.array([0, 1, 2])

# Matriz de probabilidades conjuntas P(X=x, Y=y)
# Cada fila representa un valor de X y cada columna un valor de Y
# prob_matrix[i][j] = P(X = x_vals[i], Y = y_categories[j])
prob_matrix = np.array([
    [0.10, 0.20],  # Para X=0
    [0.15, 0.25],  # Para X=1
    [0.05, 0.25]   # Para X=2
])

# Categorías de Y
y_categories = [0, 1]

# Configuración de ancho de barra y posiciones en eje X
bar_width = 0.35
positions = np.arange(len(x_vals))


# 📌 2. Creación de la figura y graficado de barras
fig, ax = plt.subplots(figsize=(10, 5))

# Colores distintos para cada categoría Y
colors = ['skyblue', 'steelblue']

# Bucle para graficar cada columna de probabilidades (Y=0 y Y=1)
for i, y in enumerate(y_categories):
    ax.bar(
        positions + i * bar_width,       # desplazamiento para no superponer barras
        prob_matrix[:, i],               # probabilidades de esta categoría
        bar_width,                       # ancho de las barras
        label=f'Y={y}',                  # etiqueta de leyenda
        color=colors[i],
        alpha=0.9
    )

    # Mostrar valor de la probabilidad encima de cada barra
    for j, val in enumerate(prob_matrix[:, i]):
        ax.text(positions[j] + i * bar_width, val + 0.005,
                f'{val:.2f}', ha='center', va='bottom', fontsize=9)

# ------------------------------------------------------------
# 📌 3. Resaltar puntos específicos de interés
# ------------------------------------------------------------

# Ejemplo: P(X ≤ 1, Y = 1)
highlight1_x = [0, 1]
highlight1_y = 1
highlight1_vals = prob_matrix[highlight1_x, highlight1_y]
ax.scatter(positions[highlight1_x] + bar_width, highlight1_vals,
           color='green', s=80, label='P(X≤1, Y=1)')

# Ejemplo: P(X = 2, Y = 0)
highlight2_x = [2]
highlight2_y = 0
highlight2_vals = prob_matrix[highlight2_x, highlight2_y]
ax.scatter(positions[highlight2_x], highlight2_vals,
           color='orange', s=80, label='P(X=2, Y=0)')

# ------------------------------------------------------------
# 📌 4. Personalización del gráfico
# ------------------------------------------------------------
ax.set_title('Distribución conjunta discreta (mejorada)', fontsize=13)
ax.set_xlabel('X (número de artículos)', fontsize=11)
ax.set_ylabel('Probabilidad', fontsize=11)
ax.set_xticks(positions + bar_width / 2)
ax.set_xticklabels(x_vals)
ax.legend()
ax.grid(axis='y', linestyle='--', alpha=0.5)

# Ajustar diseño
plt.tight_layout()
plt.show()
