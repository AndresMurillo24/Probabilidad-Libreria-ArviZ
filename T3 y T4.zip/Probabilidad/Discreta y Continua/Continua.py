

import numpy as np
import matplotlib.pyplot as plt
import arviz as az  # Librería ArviZ para análisis y validación probabilística
from scipy import integrate  # Para integrar funciones continuas

# ------------------------------------------------------
# Definición de la función de densidad conjunta f(x,y)
# ------------------------------------------------------
def f_joint(x, y):
    """
    Función de densidad conjunta f(x,y) = 4xy
    x: variable continua entre 0 y 1
    y: variable continua entre 0 y 1
    """
    return 4 * x * y

# ------------------------------------------------------
# 1. Verificación de que la función conjunta es válida
# ∫∫ f(x,y) dx dy = 1
# ------------------------------------------------------
integral_total, _ = integrate.dblquad(f_joint, 0, 1, lambda x: 0, lambda x: 1)
print(f"Verificación de integral total = {integral_total:.4f}")

# ------------------------------------------------------
# 2. Cálculo de probabilidad: P(X ≤ 0.6, Y ≤ 0.7)
# Se integra la función conjunta sobre el rectángulo [0,0.6]x[0,0.7]
# ------------------------------------------------------
prob_xy, _ = integrate.dblquad(f_joint, 0, 0.6, lambda x: 0, lambda x: 0.7)
print(f"P(X ≤ 0.6, Y ≤ 0.7) = {prob_xy:.4f}")

# ------------------------------------------------------
# 3. Cálculo de las marginales:
# f_X(x) = ∫ f(x,y) dy
# f_Y(y) = ∫ f(x,y) dx
# ------------------------------------------------------

# Marginal en x
def f_x(x):
    result, _ = integrate.quad(lambda y: f_joint(x, y), 0, 1)
    return result

# Marginal en y
def f_y(y):
    result, _ = integrate.quad(lambda x: f_joint(x, y), 0, 1)
    return result

# Evaluamos las marginales en algunos puntos
x_vals = np.linspace(0, 1, 100)
y_vals = np.linspace(0, 1, 100)
fx_vals = [f_x(x) for x in x_vals]
fy_vals = [f_y(y) for y in y_vals]

# ------------------------------------------------------
# 4. Uso de ArviZ para validar probabilísticamente:
# Creamos muestras simuladas a partir de la función conjunta
# para comparar numéricamente la distribución y graficar
# ------------------------------------------------------

# Generamos muestras usando método de aceptación-rechazo
N = 100000
samples_x = np.random.rand(N)
samples_y = np.random.rand(N)

# Densidad máxima de f(x,y) en el dominio (1,1): f(1,1)=4
u = np.random.rand(N) * 4
mask = u < f_joint(samples_x, samples_y)

# Aceptamos solo las que cumplen
samples_x = samples_x[mask]
samples_y = samples_y[mask]

# Convertimos a InferenceData de ArviZ para análisis posterior
idata = az.from_dict(posterior={"x": samples_x, "y": samples_y})

# Resumen estadístico de las muestras simuladas (opcional)
print(az.summary(idata, var_names=["x", "y"]))

# ------------------------------------------------------
# 5. Gráficas
# ------------------------------------------------------

# a) Gráfico de densidad marginal para X y Y usando ArviZ
az.plot_kde(samples_x, label="Marginal X", bw=0.05)
az.plot_kde(samples_y, label="Marginal Y", bw=0.05)
plt.title("Densidades marginales estimadas con ArviZ")
plt.xlabel("Valor")
plt.ylabel("Densidad")
plt.legend()
plt.show()

# b) Gráfico de dispersión de las muestras aceptadas
plt.figure(figsize=(7, 5))
plt.scatter(samples_x[:2000], samples_y[:2000], alpha=0.3, s=10)
plt.title("Muestras simuladas de f(x,y) = 4xy")
plt.xlabel("X")
plt.ylabel("Y")
plt.grid(alpha=0.3)
plt.show()
